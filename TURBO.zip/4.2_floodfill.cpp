#include<iostream.h>
#include<graphics.h>
#include<conio.h>

void floodFill(int x,int y,int interiorColor,int fillColor)
{
	if(getpixel(x,y) == interiorColor)
	{
		putpixel(x,y,fillColor);
		floodFill(x-1,y,interiorColor,fillColor);
		floodFill(x+1,y,interiorColor,fillColor);
		floodFill(x,y-1,interiorColor,fillColor);
		floodFill(x,y+1,interiorColor,fillColor);
		floodFill(x-1,y+1,interiorColor,fillColor);
		floodFill(x+1,y+1,interiorColor,fillColor);
		floodFill(x+1,y-1,interiorColor,fillColor);
		floodFill(x-1,y-1,interiorColor,fillColor);
	}
}

int main()
{
	int gm,gd=DETECT,radius;
	int x,y;

	initgraph(&gd,&gm,"c://turboc3//bgi");
	rectangle(20, 20, 40, 40);
    floodFill(30, 30, 15, 15);
	getch();
	closegraph();

	return 0;
}
